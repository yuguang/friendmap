/*
* Copyright 2010-2011 Research In Motion Limited.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/**
 *  called by the webworksready event when the environment is ready
 */
 
 var mapProvider = 'bing';
 var g_map;
 
function initApp() {
APIKey = {
            'bing': 'Ap76EAymF6IBSmNmnfSqNgoP8BIAD9T0m9cdXiIqlc95OkOOFnjuUwlKkat8I-Ou'
        };

        if (mapProvider == 'google') {
            initializeGoogle();
        } else {
            //initBingMaps();
        }
        //startSubscription();

        console.log('app initialized');
        //startSubscription();
        startGeolocation();
}

  var initialize, markers, infos, plot, bingMap1, selfpin = 0;

  markers = {};
  infos = {};
  
  User = (function() {

    function User(name) {
      this.name = name;
      this.color = '#' + Math.floor(Math.random() * 16777215).toString(16);
    }

    return User;

  })();
  
  /*function initializeBing() {
    console.log("initializeBing");
      setTimeout(function() {
         bingMap = new Microsoft.Maps.Map(document.getElementById("map_canvas"), {
              credentials: APIKey.bing,
              center: new Microsoft.Maps.Location(myLat, myLong),
              zoom: 14,
              mapTypeId: Microsoft.Maps.MapTypeId.road,
              showCopyright: false
          });
          
        
      }, 200);
  };*/

 function plot(location, user) {
    if(!bingMap){
        console.log("Failed!");
        return;
    }
 
    console.log("Plot!");
    var latLng;
    plotSelf();
    if (mapProvider == 'google') {
        latLng = new google.maps.LatLng(location.x, location.y);
    } else {
        latLng = new Microsoft.Maps.Location(location.x, location.y);
    }
    if (user.name in markers) {
        if (mapProvider == 'google') {
            return markers[user.name].setPosition(latLng);
        } else {
            infos[user.name].setLocation(latLng);
            return markers[user.name].setLocation(latLng);
        }
    } else {
      var info;
      if (mapProvider == 'google') {
          info = new google.maps.InfoWindow({
	        content: user.name + '<br/><img border="0" align="left" src="pics/' + user.name + '.png">'
          });
      } else {
          info = new Microsoft.Maps.Infobox(
            latLng, {title: user.name + '<br/><img border="0" align="left" src="http://friendtracker.org/client/pics/' + user.name + '.png"/>', visible: false, width: 150, height:165, showPointer: false, offset:new Microsoft.Maps.Point(-75,50)}
          );
      }
      infos[user.name] = info;

      if (mapProvider == 'google') {
          markers[user.name] = new StyledMarker({
              styleIcon: new StyledIcon(StyledIconTypes.MARKER, {
                  color: user.color
              }),
              position: latLng,
              map: bingMap
          });
      } else {
          markers[user.name] = new Microsoft.Maps.Pushpin(latLng,{
              text: user.name,
              infobox: info,
              typeName: 'pinCSS',
              textOffset: new Microsoft.Maps.Point(-user.name.length*4/3, 40)
          });
      }

      // show info window when the marker is clicked
      if (mapProvider == 'google') {
          google.maps.event.addListener(markers[user.name], 'click', function() {
              info.open(map, markers[user.name]);
          });
      } else {
          Microsoft.Maps.Events.addHandler(markers[user.name], 'click', function(e) {
              infos[user.name].setOptions({visible:false});
              info.setOptions({ visible: true });
              
          });
          console.log("Putting marker");
          bingMap.entities.push(markers[user.name]);
          bingMap.entities.push(info);
      }
      
  
      return markers[user.name];
    }
  };
  
  function plotSelf(){
  if(!bingMap) return;
    var selfLoc = new Microsoft.Maps.Location(myLat, myLong);
    if(selfpin){
    
        selfpin.setLocation(selfLoc);
    }
    else{
        selfpin = new Microsoft.Maps.Pushpin(selfLoc, {
              text: "You",
              typeName: 'pinCSS',
              textOffset: (0,50)
          });
        bingMap.entities.push(selfpin);
    }
  }
  
  decodeJSON = function(j) {
	    var coordinates, data, json;
	    json = JSON.parse(j.data)["SUBSCRIBE"];
	    if (!json || !(json[0] === "message")) {
	      json = JSON.parse(j.data)["GET"];
          if (!json || !(json[0] == "message")) {
            return false;
            }
	    }
	    coordinates = json[2].split(',');
	    data = {
	      user: new User(json[1]),
	      location: {
	        x: parseFloat(coordinates[0]),
	        y: parseFloat(coordinates[1])
	      }
	    };
	    return data;
  };
  
  function startSubscription() {
    console.log("start subscription");
      var host = "198.58.106.27";
      var port = 8081;
      var socket = new WebSocket("ws://" + host + ":" + port + "/");
      socket.onopen = function() {
      var i, _i, _results;
      // first get locations and then subscribe for later
      for (i = _i = 1; _i <= 6; i = ++_i) {
          socket.send(JSON.stringify({
              "GET": "testusr" + i
            }));
      }
      _results = [];
      for (i = _i = 1; _i <= 6; i = ++_i) {
        _results.push(socket.send(JSON.stringify({
          "SUBSCRIBE": "testusr" + i
        })));
      }
      return _results;
    };
    return socket.onmessage = function(message) {
      var data;
      data = decodeJSON(message);
      if (data) {
      
        return plot(data.location, data.user);
      }
    };
  };
  
function centerOnSelf(){
    if(bingMap){
        bingMap.setView({center: new Microsoft.Maps.Location(myLat, myLong)});
    }
}
  
  

  //google.maps.event.addDomListener(window, "load", initApp);
  

function initBingMaps() {
    console.log("InitBingMaps");
  setTimeout(function() {
    bingMap = new Microsoft.Maps.Map(document.getElementById("map_canvas"), {
      credentials: APIKey.bing,
      center: new Microsoft.Maps.Location(myLat, myLong),
      zoom: 14,
      mapTypeId: Microsoft.Maps.MapTypeId.road,
      showCopyright: false
    });
  }, 200);
}


/**
 *  google maps
 */

// initialize the map
function initGoogleMaps() {
  console.log("Init google maps");
  
  initBingMaps();
  startSubscription();
  //initApp();

  /*myLocation = new google.maps.LatLng(myLat, myLong);

  var mapOptions = {
    zoom: 14,
    center: myLocation,
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    zoomControl: false,
    mapTypeControl: false,
    streetViewControl: false
  };
  googleMap = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
  
  host = "198.58.106.27";
    port = 8081;

    socket = new WebSocket("ws://" + host + ":" + port + "/");

    socket.onopen = function() {
      var i, _i, _results;
      _results = [];
      for (i = _i = 1; _i <= 7; i = ++_i) {
        _results.push(socket.send(JSON.stringify({"SUBSCRIBE": "testusr" + i})));
      }
      return _results;
    };

    socket.onmessage = function(message) {
      var data;
      data = decodeJSON(message);
      if (data) {
    	  plot(data.location, data.user);
      }
    };
    
    socket.onclose = function() {
    	window.alert("websocket closed");
    };*/
}



// search for nearby places
function initGooglePlaces() {
  searchForPlaces(googlePlacesCallback);
}

// search callback
function googlePlacesCallback(results) {
  for(var i = 0; i < results.length; i++) {
    createGoogleMarker(results[i]);
  }
}

// create a marker / push-pin
function createGoogleMarker(place) {
  var placeLoc = place.geometry.location;
  var marker = new google.maps.Marker({
    map: googleMap,
    position: place.geometry.location
  });
}



/**
 *  bing
 */

// initialize the map


// search for nearby places
function initBingPlaces() {
  Microsoft.Maps.loadModule('Microsoft.Maps.Search', {
    callback: bingSearch
  });
}

// seraching bing, using a query
function bingSearch() {
  bingMap.addComponent('searchManager', new Microsoft.Maps.Search.SearchManager(bingMap));
  searchManager = bingMap.getComponent('searchManager');

  var query = 'bars in Waterloo, Canada';
  var request = {
    query: query,
    count: 15,
    startIndex: 0,
    bounds: bingMap.getBounds(),
    callback: bingPlacesCallback
  };
  searchManager.search(request);
}

// search callback
function bingPlacesCallback(result) {
  var searchResults = result && result.searchResults;
  if(searchResults) {
    for(var i = 0; i < searchResults.length; i++) {
      createBingMarker(searchResults[i]);
    }
  }
}

// create marker / push-pin
function createBingMarker(result) {
  if(result) {
    var pin = new Microsoft.Maps.Pushpin(result.location, null);
    bingMap.entities.push(pin);
  }
}



/**
 *  leaflet
 */

// initialize the map
function initLeafletMaps() {
  leafletMap = L.map('map_canvas').setView([myLat, myLong], 14);
  L.tileLayer('http://{s}.tile.cloudmade.com/' + APIKey.leaflet + '/997/256/{z}/{x}/{y}.png', {
    attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://cloudmade.com">CloudMade</a>',
    maxZoom: 16
  }).addTo(leafletMap);
}

// search for nearby places
function initLeafletPlaces() {
  searchForPlaces(leafletPlacesCallback);
}

// search callback
function leafletPlacesCallback(results) {
  for(var i = 0; i < results.length; i++) {
    var lat = results[i].geometry.location.Ya;
    var lon = results[i].geometry.location.Za;
    var name = results[i].name;
    var address = results[i].vicinity;

    // add marker
    var marker = L.marker([lat, lon]).addTo(leafletMap);
  }
}



/**
 *  openlayers
 */

// initialize the map
function initOpenLayersMaps() {
  openLayersMap = new OpenLayers.Map('map_canvas');
  layer = new OpenLayers.Layer.OSM("Simple OSM Map");
  openLayersMap.addLayer(layer);
  openLayersMap.setCenter(
    new OpenLayers.LonLat(myLong, myLat).transform(
    new OpenLayers.Projection("EPSG:4326"), openLayersMap.getProjectionObject()
  ), 14);
}

// search for nearby places
function initOpenLayersPlaces() {
  searchForPlaces(openLayersPlacesCallback);
}

// search callback
function openLayersPlacesCallback(results) {
  if(results) {
    openLayersOverlay = new OpenLayers.Layer.Vector('Overlay', {
      styleMap: new OpenLayers.StyleMap({
        externalGraphic: 'http://www.openlayers.org/dev/img/marker.png',
        graphicWidth: 20,
        graphicHeight: 24,
        graphicYOffset: -24,
        title: '${tooltip}'
      })
    });
    openLayersMap.addLayer(openLayersOverlay);
    createOpenLayersMarker(results);
  }
}

// create marker / push-pin
function createOpenLayersMarker(results) {
    for(var i = 0; i < results.length; i++) {
      var lat = results[i].geometry.location.Ya;
      var lon = results[i].geometry.location.Za;
      var myLocation = new OpenLayers.Geometry.Point(lon, lat).transform('EPSG:4326', 'EPSG:3857');
      openLayersOverlay.addFeatures([
      new OpenLayers.Feature.Vector(myLocation)]);
    }
}



/**
 *  search for POI
 */

// example of seraching for places using google
function searchForPlaces(callback) {
  var request = {
    location: myLocation,
    radius: 2000,
    types: ['bar']
  };

  infowindow = new google.maps.InfoWindow();
  var service = new google.maps.places.PlacesService(googleMap);
  service.search(request, callback);
  return;
}



/**
 *  geolocation
 */

// we use HTML5 Geolocation to pin-point where the user is
function startGeolocation() {
  var options;
  navigator.geolocation.getCurrentPosition(geoSuccess, geoFail, options);
}

// geolocation success callback
function geoSuccess(position) {
  var gpsPosition = position;
  var coordinates = gpsPosition.coords;
  myLat = coordinates.latitude;
  myLong = coordinates.longitude;
  bb.pushScreen('google.html', 'google');
  
  
  
}

// geolocation failure callback
function geoFail() {
  alert('Error getting your position. Using defaults instead');
  // set default position upon failure
  myLat = 43.465187;
  myLong = -80.522372;
  bb.pushScreen('google.html', 'google');
}